rust.rs :)
